package is.hi.hbv501GEfnahagsspa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfnahagsspaApplicationTests {

	@Test
	void contextLoads() {
	}

}
